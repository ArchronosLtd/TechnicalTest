(function() {
  'use strict';

  angular
    .module('angular-ac', [
      'ui.router'
    ]);

})();

(function() {
  'use strict';

  angular
    .module('angular-ac')
    .config([
      '$urlRouterProvider',
      '$stateProvider',

      function($urlRouterProvider, $stateProvider) {
        $stateProvider
          .state('activities', {
            url: '/',
            templateUrl: 'views/activities.html',
            controller: 'ActivitiesController',
            controllerAs: 'ctrl'
          })
          .state('activity_detail', {
            url: '/:id',
            templateUrl: 'views/activity_detail.html'
          });

        $urlRouterProvider.otherwise('/');
      }
    ]);

})();
(function() {
	'use strict';

	angular.module('angular-ac').service('CallService', ['$http',
		function($http) {
			var _calls = [];

			return {
				fetchAll: function fetchAll() {
					return $http.get('http://dev.archronos.com/activities').then(function success(resp) {
						// TODO: how about using the model?

						return _calls = resp.data;
					});
				},

				get: function get() {
					return _calls;
				}
			}
		}
	]);
})();
(function() {
	'use strict';

	angular
		.module('angular-ac')
		.controller('ActivitiesController', ['CallService',
			function(CallService) {
				this.init = function init() {
					// TODO: can this be done better - any ideas?
					CallService.fetchAll();
				};

				this.getCalls = function getCalls() {
					return CallService.get();
				};
			}
		]);

})();
(function() {
  'use strict';

  angular
    .module('angular-ac')
    .controller('ActivityDetailController', ['Call',
      function(Call) {
        console.info('[ActivityDetailController] init');
        // TODO: retrieve a specific call here
      }
    ]);

})();

(function() {
  'use strict';

  angular
    .module('angular-ac')
    .controller('AppController', [
      function() {
        console.info('[AppController] init');
      }
    ]);

})();

(function() {
  'use strict';

  angular
    .module('angular-ac')
    .factory('Call', [
      function() {
        var _id,
          _created,
          _direction,
          _from,
          _to,
          _via,
          _duration,
          _isArchived,
          _callType;

        function Call(raw) {
          _id = raw.id;
          _created = raw.created_at;
          _direction = raw.direction;
          _from = raw.from;
          _to = raw.to;
          _via = raw.via;
          _duration = raw.duration;
          _isArchived = raw.is_archived;
          _callType = raw.call_type;
        }

        Call.prototype.id = function() {
          return _id;
        }

        Call.prototype.created = function created() {
          return _created
        }

        Call.prototype.direction = function direction() {
          return _direction;
        }

        Call.prototype.from = function from() {
          return _from;
        }

        Call.prototype.to = function to() {
          return _to;
        }

        Call.prototype.via = function via() {
          return _via;
        }

        Call.prototype.duration = function duration() {
          return _duration;
        }

        Call.prototype.isArchived = function is_archived() {
          return _isArchived;
        }

        Call.prototype.callType = function callType() {
          return _callType;
        }

        return Call;
      }
    ]);

})();