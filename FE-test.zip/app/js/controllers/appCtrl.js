(function() {
  'use strict';

  angular
    .module('angular-ac')
    .controller('AppController', [
      function() {
        console.info('[AppController] init');
      }
    ]);

})();
