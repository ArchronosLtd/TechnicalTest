(function() {
  'use strict';

  angular
    .module('angular-ac')
    .controller('ActivityDetailController', ['Call',
      function(Call) {
        console.info('[ActivityDetailController] init');
        // TODO: retrieve a specific call here
      }
    ]);

})();
