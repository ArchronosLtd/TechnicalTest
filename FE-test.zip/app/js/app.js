(function() {
  'use strict';

  angular
    .module('angular-ac', [
      'ui.router'
    ]);

})();
